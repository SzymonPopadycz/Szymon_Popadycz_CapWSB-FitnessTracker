package com.capgemini.wsb.fitnesstracker.user.internal;

import com.capgemini.wsb.fitnesstracker.user.api.User;
import com.capgemini.wsb.fitnesstracker.user.api.UserProvider;
import com.capgemini.wsb.fitnesstracker.user.api.UserService;
import com.capgemini.wsb.fitnesstracker.user.api.SimpleUserDTO;
import com.capgemini.wsb.fitnesstracker.user.api.UserDTO;
import com.capgemini.wsb.fitnesstracker.user.api.UserNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
class UserServiceImpl implements UserService, UserProvider {

    private final UserRepository userRepository;

    @Override
    public User createUser(final User user) {
        log.info("Creating User {}", user);
        if (user.getId() != null) {
            throw new IllegalArgumentException("User has already DB ID, update is not permitted!");
        }
        return userRepository.save(user);
    }

    @Override
    public Optional<User> getUser(final Long userId) {
        return userRepository.findById(userId);
    }

    @Override
    public Optional<User> getUserByEmail(final String email) {
        return userRepository.findByEmail(email);
    }

    @Override
    public List<User> findAllUsers() {
        return userRepository.findAll();
    }

    public List<SimpleUserDTO> getAllUsersSimple() {
        return userRepository.findAll().stream()
                .map(user -> new SimpleUserDTO(user.getId(), user.getUsername()))
                .collect(Collectors.toList());
    }

    public UserDTO getUserById(Long id) {
        return userRepository.findById(id)
                .map(user -> new UserDTO(user.getId(), user.getFirstName(), user.getLastName(), user.getBirthdate(), user.getEmail(), user.getUsername()))
                .orElseThrow(() -> new UserNotFoundException(id));
    }

    public UserDTO createUser(UserDTO userDTO) {
        User user = new User(userDTO.firstName(), userDTO.lastName(), userDTO.birthdate(), userDTO.email(), userDTO.username());
        User savedUser = userRepository.save(user);
        return new UserDTO(savedUser.getId(), savedUser.getFirstName(), savedUser.getLastName(), savedUser.getBirthdate(), savedUser.getEmail(), savedUser.getUsername());
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    public List<SimpleUserDTO> findUsersByEmail(String email) {
        return userRepository.findByEmailContainingIgnoreCase(email).stream()
                .map(user -> new SimpleUserDTO(user.getId(), user.getEmail()))
                .collect(Collectors.toList());
    }

    public List<SimpleUserDTO> findUsersOlderThan(int age) {
        LocalDate date = LocalDate.now().minusYears(age);
        return userRepository.findByBirthdateBefore(date).stream()
                .map(user -> new SimpleUserDTO(user.getId(), user.getEmail()))
                .collect(Collectors.toList());
    }

    public UserDTO updateUser(Long id, UserDTO userDTO) {
        User user = userRepository.findById(id).orElseThrow(() -> new UserNotFoundException(id));
        user.setFirstName(userDTO.firstName());
        user.setLastName(userDTO.lastName());
        user.setBirthdate(userDTO.birthdate());
        user.setEmail(userDTO.email());
        user.setUsername(userDTO.username());
        User updatedUser = userRepository.save(user);
        return new UserDTO(updatedUser.getId(), updatedUser.getFirstName(), updatedUser.getLastName(), updatedUser.getBirthdate(), updatedUser.getEmail(), updatedUser.getUsername());
    }
}
