package com.capgemini.wsb.fitnesstracker.user.api;
import jakarta.annotation.Nullable;

public record SimpleUserDTO(@Nullable Long id,
                            String username) {}

