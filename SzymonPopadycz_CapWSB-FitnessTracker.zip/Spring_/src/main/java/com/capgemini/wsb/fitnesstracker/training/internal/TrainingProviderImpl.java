package com.capgemini.wsb.fitnesstracker.training.internal;

import com.capgemini.wsb.fitnesstracker.training.api.Training;
import com.capgemini.wsb.fitnesstracker.training.api.TrainingProvider;
import com.capgemini.wsb.fitnesstracker.training.api.TrainingNotFoundException;
import com.capgemini.wsb.fitnesstracker.training.api.TrainingDTO;
import com.capgemini.wsb.fitnesstracker.user.api.User;
import com.capgemini.wsb.fitnesstracker.user.internal.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class TrainingProviderImpl implements TrainingProvider {

    @Autowired
    private TrainingRepository trainingRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public Optional<Training> getTraining(Long trainingId) {
        return trainingRepository.findById(trainingId);
    }

    public List<Training> getAllTrainings() {
        return trainingRepository.findAll();
    }

    public List<Training> getTrainingsByUser(Long userId) {
        return trainingRepository.findAll().stream()
                .filter(training -> training.getUser().getId().equals(userId))
                .collect(Collectors.toList());
    }

    public List<Training> getFinishedTrainingsAfter(Date afterTime) {
        return trainingRepository.findAll().stream()
                .filter(training -> training.getEndTime().after(afterTime))
                .collect(Collectors.toList());
    }

    public List<Training> getTrainingsByActivityType(ActivityType activityType) {
        return trainingRepository.findAll().stream()
                .filter(training -> training.getActivityType().equals(activityType))
                .collect(Collectors.toList());
    }

    public Training createTraining(TrainingDTO trainingDTO) {
        User user = userRepository.findById(trainingDTO.userId())
                .orElseThrow(() -> new RuntimeException("User not found"));

        Training training = new Training(
                user,
                trainingDTO.startTime(),
                trainingDTO.endTime(),
                trainingDTO.activityType(),
                trainingDTO.distance(),
                trainingDTO.averageSpeed()
        );

        return trainingRepository.save(training);
    }

    public Training updateTraining(Long trainingId, TrainingDTO trainingDTO) {
        Training training = trainingRepository.findById(trainingId)
                .orElseThrow(() -> new TrainingNotFoundException(trainingId));

        training.setUser(userRepository.findById(trainingDTO.userId())
                .orElseThrow(() -> new RuntimeException("User not found")));
        training.setStartTime(trainingDTO.startTime());
        training.setEndTime(trainingDTO.endTime());
        training.setActivityType(trainingDTO.activityType());
        training.setDistance(trainingDTO.distance());
        training.setAverageSpeed(trainingDTO.averageSpeed());

        return trainingRepository.save(training);
    }
}
